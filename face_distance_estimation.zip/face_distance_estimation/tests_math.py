"""
tests_math.py
=============
Lightweight sanity checks for the DistanceCalculator and
AngleCalculator formulas - no camera or GUI required, so this can run
in any environment (including headless CI) to prove the math is
correct before the live demo.

Run with:
    python tests_math.py
"""

from src.distance_calculator import DistanceCalculator
from src.angle_calculator import AngleCalculator


def test_distance_known_case():
    # If W=14cm, f=615px, and the face measures 168px wide,
    # D = (14 * 615) / 168 = 51.25 cm  (roughly arm's length)
    calc = DistanceCalculator(known_face_width_cm=14.0, focal_length_px=615.0)
    d = calc.estimate_distance_cm(168)
    expected = (14.0 * 615.0) / 168
    assert abs(d - expected) < 1e-6, f"Expected {expected}, got {d}"
    print(f"[PASS] distance formula: w_px=168 -> {d:.2f} cm")


def test_distance_inverse_relationship():
    # A wider face (closer subject) must produce a SMALLER distance.
    calc = DistanceCalculator(known_face_width_cm=14.0, focal_length_px=615.0)
    d_far = calc.estimate_distance_cm(100)   # smaller face -> farther
    d_near = calc.estimate_distance_cm(300)  # larger face -> closer
    assert d_near < d_far, "Larger pixel width should mean closer distance"
    print(f"[PASS] inverse relationship: far={d_far:.1f}cm > near={d_near:.1f}cm")


def test_angle_centered():
    calc = AngleCalculator(focal_length_px=615.0)
    theta = calc.estimate_horizontal_angle_deg(face_center_x=320, image_center_x=320)
    assert abs(theta) < 1e-6, f"Expected 0 deg, got {theta}"
    print(f"[PASS] centered face -> angle = {theta:.2f} deg")


def test_angle_right_positive():
    calc = AngleCalculator(focal_length_px=615.0)
    theta = calc.estimate_horizontal_angle_deg(face_center_x=500, image_center_x=320)
    assert theta > 0, "Face right of center should give a positive angle"
    label = calc.direction_label(theta)
    assert label == "RIGHT"
    print(f"[PASS] right-of-center -> angle = {theta:+.2f} deg ({label})")


def test_angle_left_negative():
    calc = AngleCalculator(focal_length_px=615.0)
    theta = calc.estimate_horizontal_angle_deg(face_center_x=100, image_center_x=320)
    assert theta < 0, "Face left of center should give a negative angle"
    label = calc.direction_label(theta)
    assert label == "LEFT"
    print(f"[PASS] left-of-center -> angle = {theta:+.2f} deg ({label})")


def test_calibrate_focal_length_roundtrip():
    # If we "calibrate" using a known distance/width, then feed that
    # same width back into estimate_distance_cm, we should recover
    # the original known distance.
    known_distance = 50.0
    measured_width_px = 172
    f = DistanceCalculator.calibrate_focal_length(known_distance, measured_width_px, known_face_width_cm=14.0)

    calc = DistanceCalculator(known_face_width_cm=14.0, focal_length_px=f)
    recovered_distance = calc.estimate_distance_cm(measured_width_px)

    assert abs(recovered_distance - known_distance) < 1e-6
    print(f"[PASS] calibration roundtrip: recovered {recovered_distance:.2f} cm (expected {known_distance})")


if __name__ == "__main__":
    test_distance_known_case()
    test_distance_inverse_relationship()
    test_angle_centered()
    test_angle_right_positive()
    test_angle_left_negative()
    test_calibrate_focal_length_roundtrip()
    print("\nAll math sanity checks passed.")
