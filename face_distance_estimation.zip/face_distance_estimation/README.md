# Monocular Face Distance & Angle Estimation

**Hackathon Theme 2 – Task 2**
A pure-Python, CPU-only system that uses a single (monocular) 2D webcam to estimate:

1. **Distance (depth)** of a person's face from the camera.
2. **Horizontal deviation angle** of the face from the camera's optical center.

No GPU. No cloud APIs. No paid services. Runs on a normal laptop.

---

## 1. How It Works — The Pipeline

```
Camera/Image → Face Detection → Face Width in Pixels → Distance Calculation
→ Horizontal Angle Calculation → Display (bounding box + on-screen text)
```

| Stage | Module | What it does |
|---|---|---|
| Capture | `src/main.py` | Grabs frames from the webcam (or loads a static image) |
| Detect | `src/face_detector.py` | Finds the face and its bounding box using OpenCV's Haar Cascade |
| Measure | `src/face_detector.py` (`DetectedFace`) | Extracts face width in pixels + face center point |
| Distance | `src/distance_calculator.py` | Applies the pinhole camera formula to get depth in cm |
| Angle | `src/angle_calculator.py` | Applies the pinhole camera formula to get horizontal deviation in degrees |
| Display | `src/visualizer.py` | Draws the bounding box, center axis, and result text on the frame |

---

## 2. The Math

### 2.1 Pinhole Camera Model (background)

A pinhole camera projects a real-world object of width `W` at distance `D` onto the
image sensor as an object of pixel width `w_px`. By similar triangles:

```
w_px = (f * W) / D
```

where `f` is the camera's focal length **expressed in pixels** (this already accounts
for sensor size and resolution — it is not the "50mm" printed on a lens).

### 2.2 Distance (Depth) Formula

Rearranging the equation above for `D`:

```
D = (W * f) / w_px
```

| Symbol | Meaning | Source |
|---|---|---|
| `W` | Known average real face width (≈14 cm) | `config.KNOWN_FACE_WIDTH_CM` |
| `f` | Calibrated camera focal length (pixels) | `config.FOCAL_LENGTH_PX` |
| `w_px` | Measured face width in the current frame | `FaceDetector` output |
| `D` | **Estimated distance** (cm) | returned by `DistanceCalculator` |

Implemented in `src/distance_calculator.py` → `estimate_distance_cm()`.

### 2.3 Horizontal Angle Formula

The face center's horizontal pixel offset from the image's optical center relates to
the real deviation angle by:

```
theta = atan( (face_center_x - c_x) / f )
```

| Symbol | Meaning | Source |
|---|---|---|
| `face_center_x` | X-coordinate of the detected face's center | `FaceDetector` output |
| `c_x` | X-coordinate of the image's optical center (≈ `image_width / 2`) | computed from frame size |
| `f` | Same calibrated focal length used for distance | `config.FOCAL_LENGTH_PX` |
| `theta` | **Estimated horizontal deviation angle** (converted to degrees) | returned by `AngleCalculator` |

Sign convention: **positive = face is right of center, negative = face is left of
center.**

Implemented in `src/angle_calculator.py` → `estimate_horizontal_angle_deg()`.

### 2.4 Why the Same `f` Works for Both

`f` is a property of the camera/lens/resolution, not of the subject's distance — so
one calibration is reused by both formulas. This is why calibration only needs to be
done once per camera (see Section 5).

### 2.5 Expected Accuracy

This approach is a well-established, published technique for monocular depth
estimation and comfortably meets the problem statement's **±50–150 cm** accuracy
requirement for a properly calibrated camera and a face reasonably close to the
average width assumption. Accuracy is naturally lower for faces that deviate strongly
from the ~14 cm average (e.g. children) or under poor lighting that hurts detection.

---

## 3. Folder Structure

```
face_distance_estimation/
│
├── src/
│   ├── __init__.py              # Package docstring / overview
│   ├── config.py                # All tunable constants (W, f, thresholds, camera settings)
│   ├── face_detector.py         # Haar Cascade face detection + DetectedFace dataclass
│   ├── distance_calculator.py   # Pinhole-model distance math (+ calibration helper)
│   ├── angle_calculator.py      # Pinhole-model angle math
│   ├── visualizer.py            # Drawing: bounding box, center axis, HUD text
│   └── main.py                  # Pipeline entry point (webcam & static image modes)
│
├── calibration/
│   ├── __init__.py
│   └── calibrate_focal_length.py  # One-time camera calibration utility
│
├── tests_math.py                # Camera-free unit tests for the math (run anywhere)
├── requirements.txt             # opencv-python, numpy
└── README.md                    # This file
```

---

## 4. Installation

**Requirements:** Python 3.8+, a laptop with any webcam (built-in or USB), no GPU
needed.

```bash
# 1. Clone / unzip the project, then move into it
cd face_distance_estimation

# 2. (Recommended) Create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

That's it — OpenCV ships its own Haar Cascade model files internally, so **no
separate model download is required** and **no internet connection is needed** at
run time.

---

## 5. Calibration (do this once per camera, ~1 minute)

The default `FOCAL_LENGTH_PX` in `src/config.py` is a reasonable placeholder for a
typical 720p laptop webcam, but for best accuracy, calibrate it for your own camera:

```bash
python calibration/calibrate_focal_length.py --distance 50
```

1. Sit exactly **50 cm** from your webcam (measure with a ruler/tape, or pass your
   own measured distance via `--distance`).
2. A window opens showing your live face detection and pixel width.
3. Press **`s`** to capture and compute your camera's focal length.
4. Copy the printed value into `src/config.py` → `FOCAL_LENGTH_PX`.

---

## 6. Running the Project

### Live webcam (main demo)

```bash
python -m src.main
```

- Opens your webcam, detects your face in real time.
- Draws a green bounding box, an amber vertical line marking the camera's optical
  center, and displays **distance (cm/m)** and **horizontal angle (degrees)** both
  above the bounding box and in a summary panel top-left.
- Press **`q`** to quit.

### Static image

```bash
python -m src.main --image path/to/photo.jpg
```

- Runs the same pipeline on a single image file and prints the results to the
  console as well as displaying them on the image.
- Press any key to close the image window.

### Run the math sanity tests (no camera required)

```bash
python tests_math.py
```

Verifies the distance/angle formulas behave correctly (e.g. a wider face pixel width
always yields a smaller distance, a centered face yields a 0° angle, left/right faces
give correctly signed angles, and the calibration formula round-trips correctly).

---

## 7. File-by-File / Function-by-Function Explanation

### `src/config.py`
Central place for every constant so no logic file has hard-coded "magic numbers":
- `KNOWN_FACE_WIDTH_CM` — the average real-world face width used in the distance formula.
- `FOCAL_LENGTH_PX` — your calibrated camera focal length in pixels.
- `DETECTOR_*` — Haar Cascade tuning (scale factor, min neighbors, min face size).
- `CAMERA_INDEX`, `FRAME_WIDTH/HEIGHT` — webcam settings.
- `SMOOTHING_ALPHA` — controls how much frame-to-frame jitter is smoothed out.

### `src/face_detector.py`
- **`DetectedFace`** (dataclass): holds `x, y, w, h` of the bounding box, and exposes
  `.center` (tuple) and `.width_px` (int) as convenience properties.
- **`FaceDetector.__init__`**: loads OpenCV's bundled `haarcascade_frontalface_default.xml`.
- **`FaceDetector.detect(frame)`**: converts frame to grayscale, equalizes histogram
  (helps in low light), runs `detectMultiScale`, returns all faces sorted
  largest-first.
- **`FaceDetector.detect_primary(frame)`**: convenience wrapper returning only the
  single largest (closest/primary) face, or `None`.

### `src/distance_calculator.py`
- **`estimate_distance_cm(face_width_px)`**: implements `D = (W * f) / w_px`.
- **`estimate_distance_smoothed(face_width_px)`**: same formula, passed through an
  exponential moving average to stabilize the on-screen number.
- **`calibrate_focal_length(known_distance_cm, measured_face_width_px, ...)`**
  (static method): the inverse formula `f = (w_px * D) / W`, used only by the
  calibration script.

### `src/angle_calculator.py`
- **`estimate_horizontal_angle_deg(face_center_x, image_center_x)`**: implements
  `theta = atan((face_center_x - c_x) / f)`, converted to degrees.
- **`estimate_angle_smoothed(...)`**: EMA-smoothed version for stable display.
- **`direction_label(theta_deg)`**: returns `"LEFT"`, `"RIGHT"`, or `"CENTER"` for a
  friendlier HUD label (uses a small deadzone so near-zero angles read as centered).

### `src/visualizer.py`
- **`draw_face_box(frame, face)`**: draws the green bounding box + a small center dot.
- **`draw_image_center_axis(frame, image_center_x, height)`**: draws the vertical
  reference line representing the camera's true optical center.
- **`draw_hud(frame, face, distance_cm, angle_deg, direction)`**: draws the label
  above the bounding box and the top-left summary panel (distance, angle, face
  pixel width).
- **`draw_no_face_message(frame)`**: shown when no face is currently detected.

### `src/main.py`
- **`process_frame(frame, detector, dist_calc, angle_calc)`**: the single function
  that runs one frame through the entire pipeline (detect → measure → distance →
  angle → draw) and returns the annotated frame plus the raw numeric results.
- **`run_webcam()`**: opens the webcam, loops `process_frame` over each frame,
  displays the window, exits on `q`.
- **`run_single_image(image_path)`**: same pipeline but for one image file, also
  prints results to the console.
- **`main()`**: CLI argument parsing (`--image`) and dispatch.

### `calibration/calibrate_focal_length.py`
Interactive one-time tool: captures a frame at a known distance, measures the
detected face's pixel width, and computes/prints the `FOCAL_LENGTH_PX` value to paste
into `config.py`.

### `tests_math.py`
Pure-math regression tests (no camera/GUI dependency) confirming the formulas behave
correctly — useful to run before a live demo to be confident the math itself is
sound, or in a CI environment.

---

## 8. Design Notes / Why These Choices

- **Haar Cascade over a DNN face detector**: ships inside `opencv-python` with zero
  extra downloads, runs fast on CPU, and is accurate enough for a single
  roughly-front-facing user near a webcam — ideal for a hackathon demo with strict
  "no GPU, no cloud" constraints.
- **Modular design**: detection, math, and drawing are fully decoupled. The face
  detector could be swapped for a `mediapipe` or `cv2.dnn` model later without
  touching the distance/angle math or the display code at all.
- **Smoothing (EMA)**: raw per-frame detections jitter by a few pixels, which would
  make the displayed numbers flicker distractingly; the exponential moving average
  keeps the demo looking stable without adding meaningful lag.
- **Single calibrated `f` for both outputs**: keeps calibration to one simple,
  60-second step instead of two separate procedures.

---

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `Could not open webcam` | Check `CAMERA_INDEX` in `src/config.py` (try `1` if `0` fails); ensure no other app is using the webcam. |
| Face not detected | Improve lighting, face the camera more directly, or lower `DETECTOR_MIN_NEIGHBORS` in `config.py`. |
| Distance looks off | Recalibrate `FOCAL_LENGTH_PX` using `calibration/calibrate_focal_length.py` at an accurately measured distance. |
| `ModuleNotFoundError: cv2` | Run `pip install -r requirements.txt` inside your active virtual environment. |
