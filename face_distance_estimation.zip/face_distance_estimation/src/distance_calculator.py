"""
distance_calculator.py
=======================
Implements the pinhole-camera-model math that turns a face's pixel
width into a real-world distance (depth) from the camera.

--------------------------------------------------------------------
THE MATH
--------------------------------------------------------------------
A pinhole camera projects a real-world object of width `W` (cm),
located at distance `D` (cm) from the camera, onto the image sensor
as an object of pixel width `w_px`. Similar-triangles geometry gives:

                     f * W
            w_px  =  -----
                       D

Rearranging for the two quantities we care about:

    Distance:        D = (W * f) / w_px
    (Focal length, when calibrating):  f = (w_px * D) / W

Where:
    W     = known average real face width in cm      (config.KNOWN_FACE_WIDTH_CM)
    f     = camera focal length in PIXELS             (config.FOCAL_LENGTH_PX)
    w_px  = measured face width in the image, pixels  (from FaceDetector)
    D     = estimated distance from camera to face, cm  <- what we solve for

This is the exact formula required by the problem statement and is
the standard "triangle similarity" approach used in monocular
distance estimation.
--------------------------------------------------------------------
"""

from . import config


class DistanceCalculator:
    def __init__(self, known_face_width_cm: float = None, focal_length_px: float = None):
        self.known_face_width_cm = known_face_width_cm or config.KNOWN_FACE_WIDTH_CM
        self.focal_length_px = focal_length_px or config.FOCAL_LENGTH_PX
        self._smoothed_distance = None

    def estimate_distance_cm(self, face_width_px: int) -> float:
        """
        Core formula:  D = (W * f) / w_px

        Guards against a zero-width face (would divide by zero if a
        spurious/empty detection ever slipped through).
        """
        if face_width_px <= 0:
            raise ValueError("face_width_px must be > 0 to estimate distance")

        distance_cm = (self.known_face_width_cm * self.focal_length_px) / face_width_px
        return distance_cm

    def estimate_distance_smoothed(self, face_width_px: int) -> float:
        """
        Same formula as above, but passes the result through an
        exponential moving average (EMA) so the on-screen number
        doesn't flicker frame-to-frame due to detector jitter.

            smoothed = alpha * new + (1 - alpha) * previous_smoothed
        """
        raw = self.estimate_distance_cm(face_width_px)
        if self._smoothed_distance is None:
            self._smoothed_distance = raw
        else:
            a = config.SMOOTHING_ALPHA
            self._smoothed_distance = a * raw + (1 - a) * self._smoothed_distance
        return self._smoothed_distance

    @staticmethod
    def calibrate_focal_length(known_distance_cm: float, measured_face_width_px: int,
                                known_face_width_cm: float = None) -> float:
        """
        Inverse of the main formula - used ONCE during calibration.

            f = (w_px * D) / W

        Given a photo/frame taken at a KNOWN distance, this computes
        the focal length (in pixels) for your specific camera.
        """
        W = known_face_width_cm or config.KNOWN_FACE_WIDTH_CM
        return (measured_face_width_px * known_distance_cm) / W
