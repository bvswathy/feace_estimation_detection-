"""
angle_calculator.py
====================
Implements the horizontal deviation angle - how far left/right the
face is from the camera's optical (center) axis, in degrees.

--------------------------------------------------------------------
THE MATH
--------------------------------------------------------------------
In the pinhole model, the horizontal pixel offset of the face center
from the image's optical center relates to the real angle via the
focal length, again from similar triangles:

    tan(theta) = (face_center_x - c_x) / f

    theta = atan( (face_center_x - c_x) / f )

Where:
    face_center_x = x-coordinate of detected face center, in pixels
    c_x           = x-coordinate of the image's optical center
                     (usually image_width / 2)
    f             = camera focal length in pixels (same f used for
                     distance - it is a property of the camera, not
                     of distance)
    theta         = horizontal deviation angle, in radians
                     (converted to degrees for display)

Sign convention:
    theta > 0  ->  face is to the RIGHT of camera center
    theta < 0  ->  face is to the LEFT of camera center
    theta = 0  ->  face is exactly centered

This uses the SAME focal length as the distance calculation, since
both derive from one calibrated pinhole camera model - no separate
calibration is needed for the angle.
--------------------------------------------------------------------
"""

import math

from . import config


class AngleCalculator:
    def __init__(self, focal_length_px: float = None):
        self.focal_length_px = focal_length_px or config.FOCAL_LENGTH_PX
        self._smoothed_angle = None

    def estimate_horizontal_angle_deg(self, face_center_x: int, image_center_x: float) -> float:
        """
        Core formula:  theta = atan( (face_center_x - c_x) / f )
        Returned in degrees.
        """
        pixel_offset = face_center_x - image_center_x
        theta_rad = math.atan2(pixel_offset, self.focal_length_px)
        theta_deg = math.degrees(theta_rad)
        return theta_deg

    def estimate_angle_smoothed(self, face_center_x: int, image_center_x: float) -> float:
        """EMA-smoothed version, same idea as DistanceCalculator's smoothing."""
        raw = self.estimate_horizontal_angle_deg(face_center_x, image_center_x)
        if self._smoothed_angle is None:
            self._smoothed_angle = raw
        else:
            a = config.SMOOTHING_ALPHA
            self._smoothed_angle = a * raw + (1 - a) * self._smoothed_angle
        return self._smoothed_angle

    @staticmethod
    def direction_label(theta_deg: float, deadzone_deg: float = 2.0) -> str:
        """Human-readable direction label for the HUD (e.g. 'LEFT')."""
        if theta_deg > deadzone_deg:
            return "RIGHT"
        elif theta_deg < -deadzone_deg:
            return "LEFT"
        return "CENTER"
