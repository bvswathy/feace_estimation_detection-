"""
face_detector.py
=================
Wraps OpenCV's built-in Haar Cascade classifier for frontal face
detection. Chosen deliberately over deep-learning detectors (DNN/YOLO)
because it:

    - Ships INSIDE opencv-python (no extra model download, no internet)
    - Runs comfortably in real time on a CPU-only laptop
    - Needs no GPU, no cloud API call
    - Is more than accurate enough for a single, roughly front-facing
      user sitting near a webcam (the hackathon's use case)

If higher accuracy is later needed, this class can be swapped for
`cv2.dnn` + a Caffe/TensorFlow face model, or `mediapipe`, without
touching any other file - every other module only depends on the
`(x, y, w, h)` bounding box this class returns.
"""

from dataclasses import dataclass
from typing import List, Tuple

import cv2

from . import config


@dataclass
class DetectedFace:
    """Simple container describing one detected face."""
    x: int
    y: int
    w: int
    h: int

    @property
    def center(self) -> Tuple[int, int]:
        """Pixel coordinates of the face's center point (cx, cy)."""
        return (self.x + self.w // 2, self.y + self.h // 2)

    @property
    def width_px(self) -> int:
        """Face width in pixels - the key measurement for depth math."""
        return self.w


class FaceDetector:
    """Thin, swappable wrapper around cv2's Haar Cascade face detector."""

    def __init__(self):
        cascade_path = (
            cv2.data.haarcascades + config.HAAR_CASCADE_FILE
        )
        self.classifier = cv2.CascadeClassifier(cascade_path)
        if self.classifier.empty():
            raise IOError(
                f"Could not load Haar Cascade from '{cascade_path}'. "
                "Verify your OpenCV installation."
            )

    def detect(self, frame) -> List[DetectedFace]:
        """
        Detect faces in a BGR frame (as returned by cv2.VideoCapture).

        Returns a list of DetectedFace, sorted largest-first (the
        largest detected face is almost always the closest / primary
        subject, which is what we want to track).
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)  # improves detection in low light

        raw_faces = self.classifier.detectMultiScale(
            gray,
            scaleFactor=config.DETECTOR_SCALE_FACTOR,
            minNeighbors=config.DETECTOR_MIN_NEIGHBORS,
            minSize=config.DETECTOR_MIN_SIZE,
        )

        faces = [DetectedFace(x, y, w, h) for (x, y, w, h) in raw_faces]
        faces.sort(key=lambda f: f.w * f.h, reverse=True)
        return faces

    def detect_primary(self, frame) -> "DetectedFace | None":
        """Convenience helper: return only the largest/closest face."""
        faces = self.detect(frame)
        return faces[0] if faces else None
