"""
visualizer.py
=============
All drawing/HUD (heads-up display) logic lives here, kept separate
from the math and detection modules so the pipeline stays clean and
each file has a single responsibility.
"""

import cv2

from . import config
from .face_detector import DetectedFace


def draw_face_box(frame, face: DetectedFace):
    """Draw the green bounding box around the detected face."""
    cv2.rectangle(
        frame,
        (face.x, face.y),
        (face.x + face.w, face.y + face.h),
        config.BOX_COLOR,
        2,
    )
    # small filled dot at the face center point
    cv2.circle(frame, face.center, 4, config.CENTER_LINE_COLOR, -1)


def draw_image_center_axis(frame, image_center_x: int, height: int):
    """Vertical line marking the camera's true optical center (c_x)."""
    cv2.line(
        frame,
        (image_center_x, 0),
        (image_center_x, height),
        config.CENTER_LINE_COLOR,
        1,
    )


def draw_hud(frame, face: DetectedFace, distance_cm: float, angle_deg: float, direction: str):
    """
    Draws the results panel: distance in cm & meters, angle in degrees,
    and a text label directly above the bounding box.
    """
    label = f"{distance_cm/100:.2f} m | {angle_deg:+.1f} deg ({direction})"
    text_origin = (face.x, max(face.y - 12, 20))

    # background rectangle behind text for readability
    (tw, th), _ = cv2.getTextSize(
        label, cv2.FONT_HERSHEY_SIMPLEX, config.FONT_SCALE, config.FONT_THICKNESS
    )
    cv2.rectangle(
        frame,
        (text_origin[0], text_origin[1] - th - 6),
        (text_origin[0] + tw + 6, text_origin[1] + 6),
        (0, 0, 0),
        -1,
    )
    cv2.putText(
        frame,
        label,
        text_origin,
        cv2.FONT_HERSHEY_SIMPLEX,
        config.FONT_SCALE,
        config.TEXT_COLOR,
        config.FONT_THICKNESS,
        cv2.LINE_AA,
    )

    # top-left corner summary panel
    summary_lines = [
        f"Distance: {distance_cm:.1f} cm",
        f"Angle:    {angle_deg:+.2f} deg",
        f"Face w:   {face.width_px}px",
    ]
    for i, line in enumerate(summary_lines):
        cv2.putText(
            frame,
            line,
            (15, 30 + i * 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 255),
            2,
            cv2.LINE_AA,
        )


def draw_no_face_message(frame):
    """Shown when no face is currently detected in the frame."""
    cv2.putText(
        frame,
        "No face detected",
        (15, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 0, 255),
        2,
        cv2.LINE_AA,
    )
