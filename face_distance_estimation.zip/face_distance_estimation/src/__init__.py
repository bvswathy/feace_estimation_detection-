"""
Monocular Face Distance & Angle Estimation
--------------------------------------------
This package implements the full pipeline required by
Theme 2 - Task 2 of the hackathon problem statement:

    Camera/Image -> Face Detection -> Face Width in Pixels ->
    Distance Calculation -> Horizontal Angle Calculation -> Display

Modules:
    config.py               - all tunable constants (focal length, known
                               face width, thresholds, camera index, etc.)
    face_detector.py         - wraps OpenCV's Haar Cascade face detector
    distance_calculator.py   - pinhole-model depth (distance) estimation
    angle_calculator.py      - horizontal deviation angle estimation
    visualizer.py            - draws bounding boxes + on-screen HUD text
    main.py                  - ties everything together into a live pipeline
"""
