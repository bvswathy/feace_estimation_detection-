"""
main.py
=======
Entry point that wires together the full pipeline:

    Camera/Image -> Face Detection -> Face Width in Pixels ->
    Distance Calculation -> Horizontal Angle Calculation -> Display

Usage
-----
Live webcam (default):
    python -m src.main

Single static image:
    python -m src.main --image path/to/photo.jpg

Press 'q' to quit the live webcam window.
"""

import argparse
import sys

import cv2

from . import config
from .face_detector import FaceDetector
from .distance_calculator import DistanceCalculator
from .angle_calculator import AngleCalculator
from . import visualizer


def process_frame(frame, detector: FaceDetector, dist_calc: DistanceCalculator,
                   angle_calc: AngleCalculator):
    """
    Runs one frame through the full pipeline and returns the
    annotated frame plus the raw (distance_cm, angle_deg) results
    (None, None) if no face was found.
    """
    h, w = frame.shape[:2]
    image_center_x = w / 2.0

    visualizer.draw_image_center_axis(frame, int(image_center_x), h)

    face = detector.detect_primary(frame)
    if face is None:
        visualizer.draw_no_face_message(frame)
        return frame, None, None

    # ---- Step 1: face width in pixels (already inside `face`) ----
    w_px = face.width_px

    # ---- Step 2: distance via pinhole model:  D = (W * f) / w_px ----
    distance_cm = dist_calc.estimate_distance_smoothed(w_px)

    # ---- Step 3: horizontal angle: theta = atan((cx_face - cx_img)/f) ----
    face_cx, _face_cy = face.center
    angle_deg = angle_calc.estimate_angle_smoothed(face_cx, image_center_x)
    direction = angle_calc.direction_label(angle_deg)

    # ---- Step 4: draw everything ----
    visualizer.draw_face_box(frame, face)
    visualizer.draw_hud(frame, face, distance_cm, angle_deg, direction)

    return frame, distance_cm, angle_deg


def run_webcam():
    detector = FaceDetector()
    dist_calc = DistanceCalculator()
    angle_calc = AngleCalculator()

    cap = cv2.VideoCapture(config.CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)

    if not cap.isOpened():
        print("ERROR: Could not open webcam. Check CAMERA_INDEX in src/config.py")
        sys.exit(1)

    print("Live face distance & angle estimation running. Press 'q' to quit.")

    while True:
        ok, frame = cap.read()
        if not ok:
            print("ERROR: Failed to read frame from webcam.")
            break

        frame = cv2.flip(frame, 1)  # mirror view feels more natural
        frame, distance_cm, angle_deg = process_frame(frame, detector, dist_calc, angle_calc)

        cv2.imshow("Monocular Face Distance Estimation", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


def run_single_image(image_path: str):
    detector = FaceDetector()
    dist_calc = DistanceCalculator()
    angle_calc = AngleCalculator()

    frame = cv2.imread(image_path)
    if frame is None:
        print(f"ERROR: Could not read image at '{image_path}'")
        sys.exit(1)

    frame, distance_cm, angle_deg = process_frame(frame, detector, dist_calc, angle_calc)

    if distance_cm is not None:
        print(f"Estimated distance: {distance_cm:.1f} cm ({distance_cm/100:.2f} m)")
        print(f"Estimated horizontal angle: {angle_deg:+.2f} degrees")
    else:
        print("No face detected in the image.")

    cv2.imshow("Monocular Face Distance Estimation - Static Image", frame)
    print("Press any key on the image window to close.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description="Monocular Face Distance & Angle Estimation")
    parser.add_argument(
        "--image", type=str, default=None,
        help="Path to a static image file. If omitted, the live webcam is used."
    )
    args = parser.parse_args()

    if args.image:
        run_single_image(args.image)
    else:
        run_webcam()


if __name__ == "__main__":
    main()
