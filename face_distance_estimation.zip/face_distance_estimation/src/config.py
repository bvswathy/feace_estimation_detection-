"""
config.py
=========
Single source of truth for every constant used across the pipeline.

Why this file exists
---------------------
The hackathon problem statement lists five required inputs:
    1. Face center (x, y)          -> computed at runtime from detection
    2. Face width in pixels (w_px) -> computed at runtime from detection
    3. Camera focal length (f)     -> CONFIGURED HERE (must be calibrated
                                       once per camera, see calibration/)
    4. Image center (c_x, c_y)     -> computed at runtime from frame size
    5. Average real face width (W) -> CONFIGURED HERE (a well known
                                       anthropometric average)

Only #3 and #5 are "known constants" that must live somewhere static -
this file is that place, so nothing is hard-coded inside the pipeline
logic itself.
"""

# ---------------------------------------------------------------------
# 1. KNOWN REAL-WORLD FACE WIDTH (W)
# ---------------------------------------------------------------------
# Average human face width (ear-to-ear / cheekbone-to-cheekbone) is a
# well documented anthropometric value used widely in monocular
# distance-estimation literature and open-source projects.
# Typical adult value: 14.0 cm  (range roughly 12.5 - 15.5 cm)
KNOWN_FACE_WIDTH_CM = 14.0

# ---------------------------------------------------------------------
# 2. CAMERA FOCAL LENGTH IN PIXELS (f)
# ---------------------------------------------------------------------
# This is NOT the physical focal length in millimetres printed on a
# lens spec sheet - it is the focal length expressed in PIXEL units,
# which already folds in the camera's sensor size and resolution.
#
# It MUST be calibrated per camera/laptop for accurate results.
# Run `python calibration/calibrate_focal_length.py` once and paste
# the value it prints here.
#
# A reasonable placeholder for a typical 720p laptop webcam is used
# below so the project runs out-of-the-box, but real accuracy depends
# on you calibrating this value for your own camera.
FOCAL_LENGTH_PX = 615.0

# ---------------------------------------------------------------------
# 3. REFERENCE CALIBRATION SAMPLE (used only by the calibration script)
# ---------------------------------------------------------------------
# Distance (cm) at which the calibration photo/frame was captured, and
# the face pixel width measured in that frame. Used to derive
# FOCAL_LENGTH_PX = (measured_pixel_width * known_distance_cm) / KNOWN_FACE_WIDTH_CM
CALIBRATION_KNOWN_DISTANCE_CM = 50.0   # e.g. sit exactly 50 cm from webcam

# ---------------------------------------------------------------------
# 4. FACE DETECTOR SETTINGS
# ---------------------------------------------------------------------
HAAR_CASCADE_FILE = "haarcascade_frontalface_default.xml"  # bundled with cv2
DETECTOR_SCALE_FACTOR = 1.1
DETECTOR_MIN_NEIGHBORS = 5
DETECTOR_MIN_SIZE = (60, 60)   # ignore tiny/far false positives

# ---------------------------------------------------------------------
# 5. CAMERA / VIDEO SETTINGS
# ---------------------------------------------------------------------
CAMERA_INDEX = 0        # 0 = default laptop webcam
FRAME_WIDTH = 1280
FRAME_HEIGHT = 720

# ---------------------------------------------------------------------
# 6. DISPLAY SETTINGS
# ---------------------------------------------------------------------
BOX_COLOR = (0, 255, 0)          # green bounding box (BGR)
TEXT_COLOR = (255, 255, 255)     # white text
CENTER_LINE_COLOR = (0, 200, 255)
FONT_SCALE = 0.65
FONT_THICKNESS = 2

# Smoothing (exponential moving average) to stop distance/angle jitter
# frame-to-frame. 0 = no smoothing, closer to 1 = heavier smoothing.
SMOOTHING_ALPHA = 0.3
