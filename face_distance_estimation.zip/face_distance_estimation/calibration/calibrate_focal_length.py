"""
calibrate_focal_length.py
==========================
One-time calibration utility. Every camera has a different focal
length in PIXEL units (this depends on the physical lens AND the
resolution/sensor, so it must be measured per device - a value that
works for one laptop webcam will be wrong for another).

HOW TO USE
----------
1. Sit at a KNOWN, measured distance from your webcam.
   The default assumes 50 cm - measure it with a ruler/tape for
   best accuracy, or change --distance to whatever you measured.

2. Run this script:
       python calibration/calibrate_focal_length.py --distance 50

3. It opens your webcam, detects your face, and once you press 's'
   it captures the current face pixel width and computes:

       f = (w_px * known_distance_cm) / known_face_width_cm

4. Copy the printed FOCAL_LENGTH_PX value into src/config.py.

This is the standard "triangle similarity" calibration technique -
the same formula as distance estimation, just solved for f instead
of D, using one frame where the true distance is already known.
"""

import argparse
import sys
import os

# allow running this script directly (adds project root to path)
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cv2

from src import config
from src.face_detector import FaceDetector
from src.distance_calculator import DistanceCalculator


def main():
    parser = argparse.ArgumentParser(description="Calibrate camera focal length (pixels)")
    parser.add_argument(
        "--distance", type=float, default=config.CALIBRATION_KNOWN_DISTANCE_CM,
        help="Known, measured distance (cm) between your face and the camera during capture"
    )
    parser.add_argument(
        "--face-width", type=float, default=config.KNOWN_FACE_WIDTH_CM,
        help="Known real-world face width (cm). Default uses the average in config.py"
    )
    args = parser.parse_args()

    detector = FaceDetector()
    cap = cv2.VideoCapture(config.CAMERA_INDEX)

    if not cap.isOpened():
        print("ERROR: Could not open webcam.")
        sys.exit(1)

    print(f"Sit exactly {args.distance} cm from the camera.")
    print("Press 's' to capture and compute focal length, 'q' to quit without saving.")

    focal_length = None
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)

        face = detector.detect_primary(frame)
        if face is not None:
            cv2.rectangle(frame, (face.x, face.y), (face.x + face.w, face.y + face.h), (0, 255, 0), 2)
            cv2.putText(frame, f"width: {face.width_px}px  -  press 's' to capture",
                        (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        else:
            cv2.putText(frame, "No face detected", (15, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        cv2.imshow("Calibration - press 's' to capture, 'q' to cancel", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord('s') and face is not None:
            focal_length = DistanceCalculator.calibrate_focal_length(
                known_distance_cm=args.distance,
                measured_face_width_px=face.width_px,
                known_face_width_cm=args.face_width,
            )
            break
        elif key == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    if focal_length is not None:
        print("\n----------------------------------------")
        print(f"Calibrated FOCAL_LENGTH_PX = {focal_length:.2f}")
        print("----------------------------------------")
        print("Copy this value into src/config.py -> FOCAL_LENGTH_PX")
    else:
        print("Calibration cancelled - no value captured.")


if __name__ == "__main__":
    main()
